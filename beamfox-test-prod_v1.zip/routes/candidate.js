const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');

const {addCandidate,getCandidates,sendCandidateInvite,getCandidateInvite} = require('../controllers/Candidates');

router.post('/addCandidate', protect,addCandidate);
router.get('/getCandidates',protect, getCandidates);

router.post('/sendCandidateInvite',protect, sendCandidateInvite);
router.get('/candidateInvite/:userId', getCandidateInvite);


module.exports = router;