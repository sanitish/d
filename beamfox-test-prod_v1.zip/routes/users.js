const express = require('express');
const router = express.Router();
const { protect, superAdmin } = require('../middleware/auth');

const {addUser,getUsers,sendEmployeeInvitaion,getEmployeeInvitaion} = require('../controllers/users');

router.post('/addUser', addUser);
router.get('/getUsers',protect, getUsers);
router.post('/sendEmployeeInvite',protect,superAdmin, sendEmployeeInvitaion);
router.get('/employeeInvite/:companyId/:role', getEmployeeInvitaion);


module.exports = router;