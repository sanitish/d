const express = require('express');
const router = express.Router();

const {addCompany,getCompanies}= require('../controllers/companies');

router.post('/addCompany', addCompany);
router.get('/getCompanies', getCompanies);


module.exports = router;