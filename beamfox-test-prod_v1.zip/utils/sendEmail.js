const sgMail = require('@sendgrid/mail');


const sendEmail = async options => {
sgMail.setApiKey("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");
const msg = {
  to: options.email,
  from: 'nit4781@gmail.com',
    subject: options.subject,
    text: options.message,
 // html: '<strong>and easy to do anywhere, even with Node.js</strong>',
};
const result = await sgMail.send(msg);

};
module.exports = sendEmail;
