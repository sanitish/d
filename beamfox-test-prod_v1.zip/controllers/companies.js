const jwt = require('jsonwebtoken');

const Company = require('../models/Company');
const User = require('../models/User');
const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
const sendEmail = require('../utils/sendEmail');
exports.addCompany = asyncHandler(async (req,res,next) =>{
   const {name,adminEmail,designation,mobileNo,companyName,companySize,siteUrl} = req.body
   console.log(req.body)

 const company = new Company({
  adminEmail, 
  companyName,
  companySize,
  siteUrl
 })
 await company.save() 


 const user = new User({
  company:company._id,
  name,
  email:adminEmail,
  designation,
  contactNumber:mobileNo,
  role:'superAdmin',
  state:'invited',
  password:'password'

 });
 await user.save()

 //create token for url
 const token =  jwt.sign({ 
  user: user._id,
  companyName: company.companyName,
  designation: user.designation,
  email:user.email,
  name:user.name,
  contactNumber:user.contactNumber
}, //process.env.JWT_SECRET,
  'secret', {
  expiresIn: '30d'
  //process.env.JWT_EXPIRE
});


  // Create invite url
  const employeeInviteUrl = `${req.protocol}://${req.get(
    'host'
  )}/account/register/${token}`;
console.log(employeeInviteUrl)

  const message = `click the link to register: \n\n ${employeeInviteUrl}`;
  try {
  const result=   await sendEmail({
      email: company.adminEmail,
      subject: 'invite url',
      message
    });
    res.status(200).json({
      success: true,
      data: result
    });
  } catch (err) {
    console.log(err.errmsg)
        return next(new ErrorResponse('Email could not be sent', 500));
  }
  
  



});


exports.getCompanies = asyncHandler(async (req, res, next) => {
    const companies = await Company.find();
    res.status(200).json({
      success: true,
      data: companies
    });
  });