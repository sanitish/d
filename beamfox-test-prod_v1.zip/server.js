const express = require('express');
const app = express();
const cors = require('cors');
const path = require('path');

const errorHandler = require('./middleware/error');

const mongoose = require('mongoose');
const db = 'mongodb+srv://sanitish:sanitsum@stayspace-o9cle.mongodb.net/test?retryWrites=true&w=majority';
mongoose.connect(db, {
    useNewUrlParser: true,
    useCreateIndex: true,
    useFindAndModify: false,  
    useUnifiedTopology: true,
  })
  .then(()=>console.log('db connected...'))
  .catch((err)=>console.log(err));

//inti middleware
app.use(cors());
app.use(express.json({extended:false}));

//load routes
app.use('/api/company',require('./routes/companies'));
app.use('/api/auth', require('./routes/auth'));
app.use('/api/user',require('./routes/users'));
app.use('/api/candidate',require('./routes/candidate'));

app.use(errorHandler);


app.use(express.static('client/build'));

app.get('*', (req, res) =>

  res.sendFile(path.resolve(__dirname, 'client', 'build', 'index.html'))
);



const PORT = process.env.PORT||8080 ;
app.listen(PORT,()=>{
    console.log(`server is list enig on port ${PORT}`)
})