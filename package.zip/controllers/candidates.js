const Candidate = require('../models/Candidate');
const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
const sendEmail = require('../utils/sendEmail');


// @desc      Get all users
// @access    Private/Admin
exports.getCandidates = asyncHandler(async (req, res, next) => {
const candidates = await Candidate.find();
  res.status(200).json({
    success: true,
    data: candidates
  });
});

// @desc      Get all users
// @access    Private/Admin
exports.getMyCandidates = asyncHandler(async (req, res, next) => {
    const candidates = await Candidate.find({
        addedBy:employeeId
    });
      res.status(200).json({
        success: true,
        data: candidates
      });
    });
    
    
    


// @desc      Create user
// @route     POST /api/users/adduser
// @access    Private/Admin
exports.addCandiate = asyncHandler(async (req, res, next) => {
  console.log(req.body)
  const candidate = new Candidate(req.body);
  const result  =await  candidate.save() 
  res.status(200).json({
    success: true,
    data: result
  });
});

exports.sendCandidateInvite = asyncHandler(async (req, res, next) => {
    console.log(req.user);
    
      // Create invite url
      const employeeInviteUrl = `${req.protocol}://${req.get(
        'host'
      )}/api/user/candidateInvite/${req.user._id}`;
    console.log(employeeInviteUrl)
      const message = `You are receiving this email because you (or someone else) has requested the reset of a password. Please make a PUT request to: \n\n ${employeeInviteUrl}`;
    
      try {
      const result=   await sendEmail({
          email: req.body.email,
          subject: 'invite url',
          message
        });
    
        res.status(200).json({ success: true, data: 'Email sent' });
      } catch (err) {
        console.log(err);
    
    
        return next(new ErrorResponse('Email could not be sent', 500));
      }
    
    
    });
    

    
exports.getCandidateInvite = asyncHandler( async (req,res,next)=>{
    console.log(req.params.companyId);
    const userId = req.params.userId;
    const user = await User.findById(userId).select('name').populate('company','name');
    res.status(200).json({
      success: true,
      data: user
    });
  });