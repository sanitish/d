const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
const sendEmail = require('../utils/sendEmail');
  
const User = require('../models/User');
const Company = require('../models/Company');

// @desc      Get all users
// @access    Private/Admin
exports.getUsers = asyncHandler(async (req, res, next) => {
const users = await User.find();
  res.status(200).json({
    success: true,
    data: users
  });
});




// @desc      Create user
// @route     POST /api/users/adduser
// @access    Private/Admin
exports.addUser = asyncHandler(async (req, res, next) => {
  console.log(req.body)
  const user = new User(req.body);
  const result  =await  user.save() 
  res.status(200).json({
    success: true,
    data: result
  });
});


// @desc      Delete all user
// @route     DELETE /api/users/deleteAll
// @access    Private/Admin
exports.deleteUser = asyncHandler(async (req, res, next) => {
  await User.remove();

  res.status(200).json({
    success: true,
    data: {}
  });
});


// @desc      invite  link
// @access    Public
exports.sendEmployeeInvitaion = asyncHandler(async (req, res, next) => {
console.log(req.user);

  // Create invite url
  const employeeInviteUrl = `${req.protocol}://${req.get(
    'host'
  )}/api/user/employeeInvite/${req.user.company}`;
console.log(employeeInviteUrl)
  const message = `You are receiving this email because you (or someone else) has requested the reset of a password. Please make a PUT request to: \n\n ${employeeInviteUrl}`;

  try {
  const result=   await sendEmail({
      email: req.body.email,
      subject: 'invite url',
      message
    });

    res.status(200).json({ success: true, data: 'Email sent' });
  } catch (err) {
    console.log(err);


    return next(new ErrorResponse('Email could not be sent', 500));
  }


});


exports.getEmployeeInvitaion = asyncHandler( async (req,res,next)=>{
  console.log(req.params.companyId);
  const companyId = req.params.companyId;
  const company = await Company.findById(companyId).select('name');
  res.status(200).json({
    success: true,
    data: company
  });
});