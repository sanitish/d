const jwt = require('jsonwebtoken');

const Company = require('../models/Company');
const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
const sendEmail = require('../utils/sendEmail');
exports.addCompany = asyncHandler(async (req,res,next) =>{
   // const {name,admin} = req.body
   console.log(req.body)
 const company = new Company(req.body)
 const token =  jwt.sign({ 
  companyId: company._id,
  companyName: company.companyName,
  role: 'superAdmin'  ,
  adminEmail:company.adminEmail
}, //process.env.JWT_SECRET,
  'secret', {
  expiresIn: '30d'
  //process.env.JWT_EXPIRE
});


  // Create invite url
  const employeeInviteUrl = `${req.protocol}://${req.get(
    'host'
  )}/account/register/${token}`;
 // const employeeInviteUrl = `${req.protocol}://localhost:3000/account/register/${token}`;
console.log(employeeInviteUrl)

  const message = `click the link to register: \n\n ${employeeInviteUrl}`;
  try {
  const result=   await sendEmail({
      email: company.adminEmail,
      subject: 'invite url',
      message
    });
  } catch (err) {
        return next(new ErrorResponse('Email could not be sent', 500));
  }
  
 result = await company.save()
  


 res.status(200).json({
    success: true,
    data: result
  });
});


exports.getCompanies = asyncHandler(async (req, res, next) => {
    const companies = await Company.find();
    res.status(200).json({
      success: true,
      data: companies
    });
  });