const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');

const {addUser,getUsers,sendEmployeeInvitaion,getEmployeeInvitaion} = require('../controllers/users');

router.post('/addUser', addUser);
router.get('/getUsers', getUsers);
router.post('/sendEmployeeInvite',protect,authorize('superAdmin'), sendEmployeeInvitaion);
router.get('/employeeInvite/:companyId/:role', getEmployeeInvitaion);


module.exports = router;