const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');

const {addCandidate,getCandidates,sendCandidateInvite,getCandidateInvite} = require('../controllers/Candidates');

router.post('/addCandidate', addCandidate);
router.get('/getCandidates', getCandidates);

router.post('/sendCandidateInvite',protect, authorize('admin','superAdmin'), sendCandidateInvite);
router.get('/candidateInvite/:userId', getCandidateInvite);


module.exports = router;