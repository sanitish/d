const mongoose = require('mongoose');

const CandidateSchema = new mongoose.Schema({
    company: {
        type: mongoose.Schema.ObjectId,
        ref: 'Company',
        required: true
    },
    candidateName: {
        type: String,
        required: true
    },
    candidateEmail: {
        type: String,
        required: true,
        unique: true
    },
    candidateMobileNumber: {
        type: Number
    },
    candidateDesignation:{
        type:String
    },
    skills: [String],
    address: {
        city: {
            type: String,
            //    required: true,
            default: 'N/A'
        },
        state: {
            type: String,
            //required: true,
            default: 'N/A'
        },
        pincode: {
            type: String,
            //    required: true,
            default: 'N/A'
        },
        addressLine1: {
            type: String,
            //required: true,
            default: 'N/A'
        },
        addressLine2: {
            type: String,
            //     required: true,
            default: 'N/A'
        }
    },
    profilePic: { type: String, default: 'http://www.newthinktank.com/wp-content/uploads/2012/05/Gravatar.jpg' },
    about: {
        type: String
    },
    experience: {
        type: String
    },
    addedBy: {
        type: mongoose.Schema.ObjectId,
        ref: 'Users',
        required: true
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
})

module.exports = mongoose.model('Candidate', CandidateSchema);