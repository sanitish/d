class MenuItem {
    id;
    parentId;
    active;
    children;
}

export default MenuItem;
