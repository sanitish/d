import React from 'react';
import { Redirect } from 'react-router-dom';
import { Route } from 'react-router-dom';
import * as FeatherIcon from 'react-feather';

import { isUserAuthenticated, getLoggedInUser } from '../helpers/authUtils';

//import CompanyLogin from '../components/auth/Login';
import CompanyRegister from '../pages/auth/companyRegister';
import CompanyRegister2 from '../pages/auth/companyRegisterStep2';
import CompanyRegister1 from '../pages/auth/companyRegisterStep1';
import CompanyRegister3 from '../pages/auth/companyRegisterStep3';

// auth
const Login = React.lazy(() => import('../pages/auth/Login'));
const Logout = React.lazy(() => import('../pages/auth/Logout'));
const Register = React.lazy(() => import('../pages/auth/Register'));
const ForgetPassword = React.lazy(() => import('../pages/auth/ForgetPassword'));
const Confirm = React.lazy(() => import('../pages/auth/Confirm'));
// dashboard
const Dashboard = React.lazy(() => import('../pages/dashboard'));
// apps
 const CalendarApp = React.lazy(() => import('../pages/apps/Calendar'));
// const EmailInbox = React.lazy(() => import('../pages/apps/Email/Inbox'));
// const EmailDetail = React.lazy(() => import('../pages/apps/Email/Detail'));
// const EmailCompose = React.lazy(() => import('../pages/apps/Email/Compose'));
 const ProjectList = React.lazy(() => import('../pages/apps/Project/List'));
 const ProjectDetail = React.lazy(() => import('../pages/apps/Project/Detail/'));
// const TaskList = React.lazy(() => import('../pages/apps/Tasks/List'));
// const TaskBoard = React.lazy(() => import('../pages/apps/Tasks/Board'));

// pages
const Starter = React.lazy(() => import('../pages/other/Starter'));
const Profile = React.lazy(() => import('../pages/other/Profile/'));
const Activity = React.lazy(() => import('../pages/other/Activity'));
const Invoice = React.lazy(() => import('../pages/other/Invoice'));
const Pricing = React.lazy(() => import('../pages/other/Pricing'));
const Error404 = React.lazy(() => import('../pages/other/Error404'));
const Error500 = React.lazy(() => import('../pages/other/Error500'));

// ui
// const BSComponents = React.lazy(() => import('../pages/uikit/BSComponents/'));
// const FeatherIcons = React.lazy(() => import('../pages/uikit/Icons/Feather'));
// const UniconsIcons = React.lazy(() => import('../pages/uikit/Icons/Unicons'));
// const Widgets = React.lazy(() => import('../pages/uikit/Widgets/'));

// charts
const Charts = React.lazy(() => import('../pages/charts/'));

//forms
const CandidateAddForm = React.lazy(() => import('../pages/forms/CandidateAddForm'));

const BasicForms = React.lazy(() => import('../pages/forms/Basic'));
const FormAdvanced = React.lazy(() => import('../pages/forms/Advanced'));
const FormValidation = React.lazy(() => import('../pages/forms/Validation'));
const FormWizard = React.lazy(() => import('../pages/forms/Wizard'));
const FileUpload = React.lazy(() => import('../pages/forms/FileUpload'));
const Editor = React.lazy(() => import('../pages/forms/Editor'));

// tables
// const BasicTables = React.lazy(() => import('../pages/tables/Basic'));
 const AdvancedTables = React.lazy(() => import('../pages/tables/Advanced'));


// handle auth and authorization
const PrivateRoute = ({ component: Component, roles, ...rest }) => (
    <Route
        {...rest}
        render={props => {
            console.log(isUserAuthenticated())
            if (!isUserAuthenticated()) {
                // not logged in so redirect to login page with the return url
                return <Redirect to={{ pathname: '/account/login', state: { from: props.location } }} />;
            }

            const loggedInUser = getLoggedInUser();
            // check if route is restricted by role
            if (roles && roles.indexOf(loggedInUser.role) === -1) {
                // role not authorised so redirect to home pagecon
                return <Redirect to={{ pathname: '/pages/error-500' }} />;
            }

            // authorised so return component
            return <Component {...props} />;
        }}
    />
);

// root routes
const rootRoute = {
    path: '/',
    exact: true,
    component: () => <Redirect to="/dashboard" />,
    route: PrivateRoute,
};

// dashboards
const dashboardRoutes = {
    path: '/dashboard',
    name: 'Dashboard',
    icon: FeatherIcon.Home,
    header: 'Navigation',
    badge: {
        variant: 'success',
        text: '1',
    },  
    component: Dashboard,
    roles: ['superAdmin','admin'],
    route: PrivateRoute
};

// apps

const calendarAppRoutes = {
    path: '/apps/calendar',
    name: 'Calendar',
    icon: FeatherIcon.Calendar,
    component: CalendarApp,
    route: PrivateRoute,
    roles: ['superAdmin','admin'],
};

// const emailAppRoutes = {
//     path: '/apps/email',
//     name: 'Email',
//     icon: FeatherIcon.Inbox,
//     children: [
//         {
//             path: '/apps/email/inbox',
//             name: 'Inbox',
//             component: EmailInbox,
//             route: PrivateRoute,
//             roles: ['superAdmin','admin'],
//         },
//         {
//             path: '/apps/email/details',
//             name: 'Details',
//             component: EmailDetail,
//             route: PrivateRoute,
//             roles: ['superAdmin','admin'],
//         },
//         {
//             path: '/apps/email/compose',
//             name: 'Compose',
//             component: EmailCompose,
//             route: PrivateRoute,
//             roles: ['superAdmin','admin'],
//         },
//     ]
// };

const projectAppRoutes = {
    path: '/apps/candidates',
    name: 'Candidates',
    icon: FeatherIcon.Users,
    children: [
        {
            path: '/apps/candidates/list',
            name: 'List',
            component: ProjectList,
            route: PrivateRoute,
            roles: ['superAdmin','admin'],
        },
        {
            path: '/apps/candidates/detail',
            name: 'Profile',
            component: Profile,
            route: PrivateRoute,
            roles: ['superAdmin','admin'],
        },
        {
            path: '/apps/candidates/add',
            name: 'Add Candidate',
            component: CandidateAddForm,
            route: PrivateRoute,
            roles: ['superAdmin','admin'],
        }
    ]
};

// const taskAppRoutes = {
//     path: '/apps/tasks',
//     name: 'Tasks',
//     icon: FeatherIcon.Bookmark,
//     children: [
//         {
//             path: '/apps/tasks/list',
//             name: 'List',
//             component: TaskList,
//             route: PrivateRoute,
//             roles: ['superAdmin','admin'],
//         },
//         {
//             path: '/apps/tasks/board',
//             name: 'Board',
//             component: TaskBoard,
//             route: PrivateRoute,
//             roles: ['superAdmin','admin'],
//         },
//     ],
// };

//const appRoutes = [calendarAppRoutes, emailAppRoutes, projectAppRoutes, taskAppRoutes];


const appRoutes = [calendarAppRoutes,projectAppRoutes];


const settingRoutes = {
    path: '/apps/settings',
    name: 'settings',
    header:'COMPANY',
    icon: FeatherIcon.Settings,
    children: [
        {
            path: '/apps/settings/list',
            name: 'Team Managment',
            component: AdvancedTables,
            header:'COMPANY',
            route: PrivateRoute,
            roles: ['superAdmin','admin'],
        },

        {
            path: '/apps/settings/invite-team',
            name: 'Invite Team',
            component: BasicForms,
            route: PrivateRoute,
            roles: ['superAdmin'],

        },
    ]
};
// pages
const pagesRoutes = {
    path: '/pages',
    name: 'Pages',
    icon: FeatherIcon.FileText,
    children: [
        {
            path: '/pages/starter',
            name: 'Starter',
            component: Starter,
            route: PrivateRoute,
            roles: ['superAdmin','admin'],
        },
        {
            path: '/pages/profile',
            name: 'Profile',
            component: Profile,
            route: PrivateRoute,
            roles: ['superAdmin','admin'],
        },
        {
            path: '/pages/activity',
            name: 'Activity',
            component: Activity,
            route: PrivateRoute,
            roles: ['superAdmin','admin'],
        },
        {
            path: '/pages/invoice',
            name: 'Invoice',
            component: Invoice,
            route: PrivateRoute,
            roles: ['superAdmin','admin'],
        },
        {
            path: '/pages/pricing',
            name: 'Pricing',
            component: Pricing,
            route: PrivateRoute,
            roles: ['superAdmin','admin'],
        },
        {
            path: '/pages/error-404',
            name: 'Error 404',
            component: Error404,
            route: Route
        },
        {
            path: '/pages/error-500',
            name: 'Error 500',
            component: Error500,
            route: Route
        },
    ]
};



// forms
const formsRoutes = {
    path: '/forms',
    name: 'Forms',
    icon: FeatherIcon.FileText,
    children: [

        
 
        
        {
            path: '/forms/basic',
            name: 'Invite Team',
            component: BasicForms,
            route: PrivateRoute,
            roles: ['superAdmin'],

        },
        
    ]
};



// auth
const authRoutes = {
    path: '/account',
    name: 'Auth',
    children: [
        {
            path: '/account/login',
            name: 'Login',
            component: Login,
            route: Route,
        },
        {
            path: '/account/logout',
            name: 'Logout',
            component: Logout,
            route: Route,
        },
        {
            path: '/account/companyRegister',
            name: 'CompanyRegister',
            component: CompanyRegister,
            route: Route,
        },
        {
            path: '/account/companyRegister1',
            name: 'CompanyRegister',
            component: CompanyRegister1,
            route: Route,
        },
        {
            path: '/account/companyRegister2',
            name: 'CompanyRegister',
            component: CompanyRegister2,
            route: Route,
        },
        {
            path: '/account/companyRegister3',
            name: 'CompanyRegister',
            component: CompanyRegister3,
            route: Route,
        },

        {
            path: '/account/register/:id',
            name: 'Register',
            component: Register,
            route: Route,
        },
        {
            path: '/account/confirm',
            name: 'Confirm',
            component: Confirm,
            route: Route,
        },
        {
            path: '/account/forget-password',
            name: 'Forget Password',
            component: ForgetPassword,
            route: Route,
        },
        {
            path: '/form/candidateProfile/:id',
            name: 'Advanced',
            component: FormAdvanced,
            route: Route,
        },
        // {
        //     path: '/account/companyLogin',
        //     name: 'company login',
        //     component: CompanyLogin,
        //     route: Route,
        // },
    ],
};




const workflow = {
    path: '/apps/workflow',
    name: 'Workflow',
    header:'Custom',
    icon: FeatherIcon.Activity,
    children: [
        {
            path: '/apps/workflow/create',
            name: 'Create Workflow',
            component: Error404,
            route: PrivateRoute,
            roles: ['superAdmin','admin'],
        },
        {
            path: '/apps/workflow/get',
            name: 'Workflows',
            component: Error404,
            route: PrivateRoute,
            roles: ['superAdmin','admin'],
        },
    ]
};



const myTask = {
    path: '/apps/mytasks',
    name: 'My Tasks',
    icon: FeatherIcon.Bookmark,
    children: [
        {
            path: '/apps/mytasks/create',
            name: 'Create Workflow',
            component: Error404,
            route: PrivateRoute,
            roles: ['superAdmin','admin'],
        },
        {
            path: '/apps/mytasks/get',
            name: 'Workflows',
            component: Error404,
            route: PrivateRoute,
            roles: ['superAdmin','admin'],
        },
    ]
};



// flatten the list of all nested routes
const flattenRoutes = routes => {
    let flatRoutes = [];

    routes = routes || [];
    routes.forEach(item => {
        flatRoutes.push(item);

        if (typeof item.children !== 'undefined') {
            flatRoutes = [...flatRoutes, ...flattenRoutes(item.children)];
        }
    });
    return flatRoutes;
};

// All routes
const allRoutes = [
    rootRoute,
    dashboardRoutes,
 ...appRoutes,
   // pagesRoutes,
  //  componentsRoutes,
    //chartRoutes,
    //tableRoutes,
    authRoutes,
    settingRoutes,
    pagesRoutes,
    workflow,
    myTask

];

const authProtectedRoutes = [dashboardRoutes,...appRoutes,workflow,myTask,settingRoutes];
const allFlattenRoutes = flattenRoutes(allRoutes);
export { allRoutes, authProtectedRoutes, allFlattenRoutes };
