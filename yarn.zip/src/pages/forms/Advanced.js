import React from 'react';
import { AvForm, AvField, AvGroup, AvInput, AvFeedback } from 'availity-reactstrap-validation';
import { Row, Col, Card, CardBody, Button, InputGroupAddon, Label, FormGroup, CustomInput, Form } from 'reactstrap';

import Select from 'react-select';
import MaskedInput from 'react-text-mask';
import Flatpickr from 'react-flatpickr'

import PageTitle from '../../components/PageTitle';


const ReactSelect = () => {
    return (
        <Card>
            <CardBody>
                <h4 className="header-title mt-0 mb-1">Skills Select <a href="https://github.com/JedWatson/react-select" className="ml-2 font-size-13"><i className='uil uil-external-link-alt'></i></a></h4>
                <Row>
           
                    <Col xl={6}>
                        <p className="mb-1 mt-3 font-weight-bold">Skills</p>
                        <p className="text-muted font-size-14">Select Your Skills (Multiple) element</p>
                        <Select
                            isMulti={true}
                            options={[
                                { value: 'chocolate', label: 'Chocolate' },
                                { value: 'strawberry', label: 'Strawberry' },
                                { value: 'vanilla', label: 'Vanilla' },
                            ]}
                            className="react-select"
                            classNamePrefix="react-select"></Select>
                    </Col>
                </Row>
                
            </CardBody>
        </Card>
    );
};


const DatePickers = () => {
    return (
        <Card>
            <CardBody>
                {/* <h4 className="header-title mt-0 mb-1">Date &amp; Time Picker</h4>
                <p className="text-muted font-size-14">
                    A simple date picker using <a href="https://flatpickr.js.org/">Flatpickr</a>
                </p> */}

                <Row>
                    <Col lg={6}>
                    <h4 className="header-title mt-0 mb-1">Address &amp;Contact Info</h4>
                <p className="text-muted font-size-14">
                    A simple date picker using <a href="https://flatpickr.js.org/">Flatpickr</a>
                </p>
                    <Card>
                        <CardBody>
                          
                            <AvForm>
                    

                                <AvField name="City" label="City" type="text" required />
                                <AvField name="State" label="State" type="text" required />
                                <AvField name="Zip" label="Zip" type="text" required />

                        
                            </AvForm>
                        </CardBody>
                    </Card>
                       </Col>
                    <Col lg={6}>
               
                    <Card>
                        <CardBody>
                          
                 <AvForm>
           
                 <AvField name="Country" label="City" type="text" required />
                                <AvField name="State" label="State" type="text" required />
                                <AvField name="Zip" label="Zip" type="text" required />

                        
                 </AvForm>
                 </CardBody>
                 </Card>

                    </Col>
                </Row>

           
            </CardBody>
        </Card>
    );
};

const InputMasks = () => {
    return (
        <Card>
            <CardBody>
            <h4 className="header-title mt-0 mb-1"> Personal Info</h4>
                <p className="text-muted font-size-14">
                   Personal Info<a href="https://flatpickr.js.org/">Flatpickr</a>
                </p>

                <Row>
                     <Col lg={6}>
                         <AvForm>
                         <AvField name="firstname" label="First Name" type="text" required />
                                <AvField name="lastname" label="Last Name" type="text" required />

                     <AvGroup>
                                    <Label for="username">Username</Label>
                                    <div className="input-group">
                                        <InputGroupAddon addonType="prepend">@</InputGroupAddon>
                                        <AvInput placeholder="Username" name="username" required />
                                        <AvFeedback>Please choose a username.</AvFeedback>
                                    </div>
                                </AvGroup>
                                </AvForm>
                         </Col>
                        
                    <Col lg={6}> 
                        <div className="form-group">
                            <label>Mobile Number</label> <br />
                            <MaskedInput
                                mask={[
                                    '(',
                                    /[1-9]/,
                                    /\d/,
                                    /\d/,
                                    ')',
                                    ' ',
                                    /\d/,
                                    /\d/,
                                    /\d/,
                                    '-',
                                    /\d/,
                                    /\d/,
                                    /\d/,
                                    /\d/,
                                ]}
                                placeholder="(___) ___-____"
                                className="form-control"
                            />
                        </div>
                    </Col>
                </Row>

                <Row>
                    <Col lg={6}>
                        <div className="form-group">
                            <label>Date Of Birth</label> <br />
                            <MaskedInput
                                mask={[/\d/, /\d/, '/', /\d/, /\d/, '/', /\d/, /\d/, /\d/, /\d/]}
                                placeholder="__/__/____"
                                className="form-control"
                            />
                        </div>
                    </Col>
                    {/* <Col lg={6}>
                        <div className="form-group">
                            <label>Time</label> <br />
                            <MaskedInput
                                mask={[/\d/, /\d/, ':', /\d/, /\d/, ':', /\d/, /\d/]}
                                placeholder="__:__:__"
                                className="form-control"
                            />
                        </div>
                            </Col>*/}
                </Row> 
            </CardBody>
        </Card>
    );
};

const FormAdvanced = () => {
    return (
        <React.Fragment className="container">
            <Row className="page-title">
                <Col md={12}>
                    {/* <PageTitle
                        // breadCrumbItems={[
                        //     { label: 'Forms', path: '/forms/advanced' },
                        //     { label: 'Form Advanced', path: '/forms/advanced', active: true },
                        // ]}
                        title={'Form Advanced'}
                    /> */}
                        <h4 className="header-title mt-0">Assemble the team</h4>
                <p className="text-muted">
                    Enter the name and email of your team. And send invite{' '}
                </p>
                </Col>
            </Row>

            <Row>
                <Col md={6}>
                    <ReactSelect />
                </Col>
            </Row>

            <Row>
                <Col  md={6}>
                    <DatePickers />
                </Col>
                <Col  md={6}>
                    <InputMasks />
                </Col>
            </Row>
            <Form>
            <FormGroup>
                                    <input
                                        tag={CustomInput}
                                        type="checkbox"
                                        name="customCheckbox"
                                        label="Agree to terms and conditions"
                                        required
                                    />
                                </FormGroup></Form>
            <Row>
              
            </Row>
        </React.Fragment>
    );
};

export default FormAdvanced;
