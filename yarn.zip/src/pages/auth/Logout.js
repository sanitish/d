import React, { useState, useContext, useEffect } from 'react';
import { connect } from 'react-redux';
import { withRouter, Redirect } from 'react-router-dom'

import AuthContext from '../../context/auth/authContext';

    
const Logout = (props)=> {
    const authContext = useContext(AuthContext);

    const { logout } = authContext;

    useEffect(()=>{
       logout(props.history);
    },[]); 
    

        return (

            <React.Fragment>

        </React.Fragment>
        )
    }


export default Logout;