import React, { useState, useContext, useEffect } from 'react';
import { connect } from 'react-redux';
import { Redirect, Link } from 'react-router-dom'

import { Container, Row, Col, Card, CardBody, Label, FormGroup, Button, Alert, InputGroup, InputGroupAddon, CustomInput } from 'reactstrap';
import { AvForm, AvGroup, AvInput, AvFeedback } from 'availity-reactstrap-validation';
import { Mail, Lock, User } from 'react-feather';

import { isUserAuthenticated } from '../../helpers/authUtils';
import Loader from '../../components/Loader';
import logo from '../../assets/images/logo.jpeg';



import AuthContext from '../../context/auth/authContext';

const CompanyRegister = props => {
    const authContext = useContext(AuthContext);
    const { companyRegister, loading, error, clearErrors, isAuthenticated } = authContext;

    console.log('login before', loading)
    useEffect(() => {
        console.log('bad bad bad')
        document.body.classList.add('authentication-bg');
        // Specify how to clean up after effect:
        return function cleanup() {
            document.body.classList.remove('authentication-bg');
        };
    }, []);

    const [user, setUser] = useState({
        companyName: '',
        adminEmail: ''
    });

    const { companyName, adminEmail } = user;

    /**
    * Handles the submit
    */

    const onChange = e => setUser({ ...user, [e.target.name]: e.target.value });

    const handleValidSubmit = (event) => {
        //  console.log(email,password)
        companyRegister({ companyName, adminEmail }, props.history);

    }
    console.log(loading)

    /**
    * Redirect to root
    */
    const renderRedirectToRoot = () => {
        const isAuthTokenValid = isUserAuthenticated();
        if (isAuthTokenValid) {
            return <Redirect to='/' />
        }
    }


    const isAuthTokenValid = isUserAuthenticated();
    return (
        <React.Fragment>

            {/* {renderRedirectToRoot()} */}

            {<div className="account-pages mt-5 mb-5">
                <Container>
                    <Row className="justify-content-center">
                        <Col xl={10}>
                            <Card className="">
                                <CardBody className="p-0">
                                    <Row>
                                        <Col md={6} className="p-5 position-relative">
                                            { /* preloader */}
                                            {loading && <Loader />}

                                            <div className="mx-auto mb-5">
                                                <a href="/">
                                                    <img src={logo} alt="" height="24" />
                                                    <h3 className="d-inline align-middle ml-1 text-logo">Beamfox</h3>
                                                </a>
                                            </div>

                                            <h6 className="h5 mb-0 mt-4">Register Your Company!</h6>
                                            <p className="text-muted mt-1 mb-4">Enter your email address and company name to access register.</p>


                                            {error && <Alert color="danger" isOpen={error ? true : false}>
                                                <div>{error}</div>
                                            </Alert>}

                                            <AvForm onValidSubmit={handleValidSubmit} className="authentication-form">
                                                <AvGroup className="">
                                                    <Label for="companyName">Company Name</Label>
                                                    <InputGroup>
                                                        <InputGroupAddon addonType="prepend">
                                                            <span className="input-group-text">
                                                                <User className="icon-dual" />
                                                            </span>
                                                        </InputGroupAddon>
                                                        <AvInput type="text" name="companyName" id="companyName" value={companyName} placeholder="Shreyu N" required onChange={onChange} />
                                                    </InputGroup>

                                                    <AvFeedback>field is invalid</AvFeedback>
                                                </AvGroup>
                                                <AvGroup className="">
                                                    <Label for="email">Email</Label>
                                                    <InputGroup>
                                                        <InputGroupAddon addonType="prepend">
                                                            <span className="input-group-text">
                                                                <Mail className="icon-dual" />
                                                            </span>
                                                        </InputGroupAddon>
                                                        <AvInput type="email" name="adminEmail" id="adminEmail" value={adminEmail} placeholder="hello@coderthemes.com" required onChange={onChange} />
                                                    </InputGroup>

                                                    <AvFeedback>field is invalid</AvFeedback>
                                                </AvGroup>



                                                <AvGroup check className="mb-4">
                                                    <CustomInput type="checkbox" id="terms" defaultChecked="true" className="pl-1" label="I accept Terms and Conditions" />
                                                </AvGroup>

                                                <FormGroup className="form-group mb-0 text-center">
                                                    <Button color="primary" className="btn-block">Sign Up</Button>
                                                </FormGroup>
                                            </AvForm>
                                        </Col>

                                        <Col md={6} className="d-none d-md-inline-block">
                                            <div className="auth-page-sidebar">
                                                <div className="overlay"></div>
                                                <div className="auth-user-testimonial">
                                                    <p className="font-size-24 font-weight-bold text-white mb-1">I simply love it!</p>
                                                    <p className="lead">"It's a elegent templete. I love it very much!"</p>
                                                    <p>- Admin User</p>
                                                </div>
                                            </div>
                                        </Col>
                                    </Row>
                                </CardBody>
                            </Card>
                        </Col>
                    </Row>

                    <Row className="mt-1">
                        <Col className="col-12 text-center">
                            <p className="text-muted">Already have an account? <Link to="/account/login" className="text-primary font-weight-bold ml-1">Sign In</Link></p>
                        </Col>
                    </Row>
                </Container>
            </div>}
        </React.Fragment>
    )
};




export default CompanyRegister;