import React, { useState, useContext, useEffect } from 'react';
import { connect } from 'react-redux';
import { Redirect, Link } from 'react-router-dom'
import {
    Input,
    FormText

} from 'reactstrap';
import { Container, Row, Col, Card, CardBody, Label, FormGroup, Button, Alert, InputGroup, InputGroupAddon, CustomInput } from 'reactstrap';
import { AvForm, AvGroup, AvInput, AvFeedback } from 'availity-reactstrap-validation';
import { Mail, Lock, User } from 'react-feather';

import { isUserAuthenticated } from '../../helpers/authUtils';
import Loader from '../../components/Loader';
import logo from '../../assets/images/logo.png';



import AuthContext from '../../context/auth/authContext';
import CompanyContext from '../../context/company/companyContext';

const CompanyRegister1 = props => {
    const authContext = useContext(AuthContext);
    const { companyRegister, loading, error, clearErrors, isAuthenticated } = authContext;

    const companyContext = useContext(CompanyContext);
const {registerDetail,formInput,clearForm} = companyContext;
useEffect(() => {
    clearForm()
    console.log('bad bad bad')
    document.body.classList.add('authentication-bg');
    // Specify how to clean up after effect:
    return function cleanup() {
        document.body.classList.remove('authentication-bg');
    };
}, []);
    const [user, setUser] = useState({
        adminEmail: '',
        name:''
    });

    const {  adminEmail ,name} = user;

    /**
    * Handles the submit
    */

    const onChange = e => setUser({ ...user, [e.target.name]: e.target.value });

    const handleValidSubmit = (event) => {
        //  console.log(email,password)
        formInput({  adminEmail ,name});
       props.history.push('/account/companyRegister2');

    }
    console.log(loading)

    /**
    * Redirect to root
    */
    const renderRedirectToRoot = () => {
        const isAuthTokenValid = isUserAuthenticated();
        if (isAuthTokenValid) {
            return <Redirect to='/' />
        }
    }


    const isAuthTokenValid = isUserAuthenticated();
    return (
        <React.Fragment>

            {/* {renderRedirectToRoot()} */}

            {<div className="account-pages mt-5 mb-5">
                <Container>
                    <Row className="justify-content-center">
                        <Col xl={10}>
                            <Card className="">
                                <CardBody className="p-0">
                                    <Row>
                                        <Col md={6} className="p-5 position-relative">
                                            { /* preloader */}
                                            {loading && <Loader />}

                                            <div className="mx-auto mb-5">
                                                <a href="/">

                                                <img className="logo" src={logo} alt="" height="24" />
                                                    <h3 className="d-inline align-middle ml-1 text-logo text-primary " >Beamfox</h3>
                                          
                                                </a>
                                            </div>
                                            <h6 className="h5 mb-2 mt-4">Try Beamfox for free</h6>
                                            <small>  <p className="text-muted mt-1 mb-0">*14-day trial , no credit card required.</p></small>
                                          <small> <p className="text-muted mb-4">*Get all the feather Beamfoxhas to offer.</p></small>
                                  
                                            {error && <Alert color="danger" isOpen={error ? true : false}>
                                                <div>{error}</div>
                                            </Alert>}

                                            <AvForm onValidSubmit={handleValidSubmit} className="authentication-form mt-5 ">
          
                                            <AvGroup className="">
                                                    <Label for="name">Name</Label>
                                                        <InputGroup>
                                                   
                                                        <AvInput  type="text" name="name" id="exampleEmail2" placeholder="" value={name}onChange={onChange} />
                                                        </InputGroup>
                                                        
                                                        <AvFeedback>This field is invalid</AvFeedback>
                                                    </AvGroup>
                                                <AvGroup className="">
                                                        <Label for="email">Email</Label>
                                                        <InputGroup>
                                                   
                                                            <AvInput  type="email" name="adminEmail" id="exampleEmail2" placeholder="" value={adminEmail}onChange={onChange} required />
                                                        </InputGroup>
                                                        
                                                        <AvFeedback>This field is invalid</AvFeedback>
                                                    </AvGroup>
                                                    

                                        
                                                    



                                                <FormGroup className="form-group mb-0 mt-5 text-center">

                                                    <Button color="danger" className="btn align-items-center btn-lg" style={{paddingLeft:"15%",paddingRight:"15%"}}>

                                                     Get Started<i className="uil uil-arrow-right mr-1 ml-2"></i>


                                                    </Button>
                                                </FormGroup>
                                            </AvForm>
                                        </Col>

                                        <Col md={6} className="d-none d-md-inline-block">
            

                                            <div className="auth-page-sidebar">
                                                <div className=""></div>
                                                <div className="auth-user-testimonial">
                                                    <p className="font-size-24 font-weight-bold text-white mb-1">I simply love it!</p>
                                                    <p className="lead">"It's a elegent templete. I love it very much!"</p>
                                                    <p>- Admin User</p>
                                                </div>
                                            </div>
                                        </Col>
                                        </Row>
                                </CardBody>
                            </Card>
                        </Col>
                    </Row>

                    <Row className="mt-1">
                        <Col className="col-12 text-center">
                            <p className="text-muted">Already have an account? <Link to="/account/login" className="text-primary font-weight-bold ml-1">Sign In</Link></p>
                        </Col>
                    </Row>
                </Container>
            </div>}
        </React.Fragment>
    )
};




export default CompanyRegister1;