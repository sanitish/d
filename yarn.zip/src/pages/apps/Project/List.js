// @flow
import React, { useContext, useEffect } from 'react';
import { Row, Col, Card, CardBody, Progress, UncontrolledTooltip, Button } from 'reactstrap';
import classNames from 'classnames';
import { Link } from 'react-router-dom';
import avatar1 from '../../../assets/images/users/avatar-6.jpg';
import avatar3 from '../../../assets/images/users/avatar-8.jpg';
import AuthContext from '../../../context/auth/authContext';
import Avatar from 'react-avatar';

import Loader from '../../../components/Loader';

// single project
const Project = ({ project }) => {

    return (
        <Card >
            <CardBody style={{ padding: "10px" }}>
                <Row className="align-items-center"  >

                    <Col className="col-sm-auto">
                        <ul className="list-inline mb-0">
                            <li className="list-inline-item pr-5">
                                <a href="/" className="d-inline-block">
                                    <Avatar name={project.candidateName} size="30" round={true} />
                                </a>
                            </li>
                            <li className="list-inline-item pr-5">
                                <Link to="/apps/projects/detail" className="text-dark">
                                    {project.candidateName}
                                </Link>
                            </li>

                            <li className="list-inline-item pr-5">
                                Team-<span style={{ color: "red" }}> {project.team}</span>
                            </li>
                            <li className="list-inline-item pr-5">
                                Manager-<span style={{ color: "blue" }}> {project.manager}</span>
                            </li>
                            <li className="list-inline-item pr-5">
                                WorkFlow Assigened- <span style={{ text: "bold" }}>No</span>

                            </li>
                        </ul>
                    </Col>

                </Row>






            </CardBody >

            {/* <CardBody  className="border-top" style={{padding:"3px"}}>
                <Row className="align-items-center">
                    <Col className="col-sm-auto">
                        <ul className="list-inline mb-0">
                            <li className="list-inline-item pr-2">
                                <a href="/" className="text-muted d-inline-block" id={`dueDate-${project.id}`}>
                                    <i className="uil uil-calender mr-1"></i> {project.dueDate}
                                </a>
                                <UncontrolledTooltip placement="top" target={`dueDate-${project.id}`}>Joining date</UncontrolledTooltip>
                            </li>
                            <li className="list-inline-item pr-2">
                                <a href="/" className="text-muted d-inline-block" id={`noTasks-${project.id}`}>
                                    <i className="uil uil-bars mr-1"></i> {project.totalTasks}</a>
                                <UncontrolledTooltip placement="top" target={`noTasks-${project.id}`}>Tasks</UncontrolledTooltip>
                            </li>
                     
                            <li className="list-inline-item">
                                <a href="/" className="text-muted d-inline-block" id={`healthStatus-${project.id}`}>
                                    <i className="uil uil-heart mr-1"></i>100%
                                </a>
                                <UncontrolledTooltip placement="top" target={`healthStatus-${project.id}`}>Health Score</UncontrolledTooltip>

                            </li>
                        </ul>
                    </Col>
                    <Col className="offset-sm-1">
                        {project.progress < 30 && (
                            <Progress value={project.progress} color="warning" className="progress-sm" />
                        )}
                        {project.progress > 30 && project.progress < 100 && (
                            <Progress value={project.progress} color="info" className="progress-sm" />
                        )}
                        {100 === 100 && (
                            <Progress value={100} color="success" className="progress-sm" />
                        )}
                    </Col>
                </Row>
            </CardBody > */}
        </Card>
    );
};

const Projects = () => {

    // const project = props.project || {};
    const authContext = useContext(AuthContext);

    const { addEmployee, loading, error, addCandidate, contacts, getCandidates } = authContext;
    useEffect(() => {
        getCandidates()
        console.log('bc ye v hai re ')
        document.body.classList.add('authentication-bg');
        // Specify how to clean up after effect:
        return function cleanup() {
            document.body.classList.remove('authentication-bg');
        };
    }, []);
    return (
        <React.Fragment>
            <Row className="page-title">
                <Col md={3} xl={6}>
                    <h4 className="mb-1 mt-0">Candidates</h4>
                </Col>
                <Col md={9} xl={6} className="text-md-right">
                    <div className="mt-4 mt-md-0">
                        <Link to="/apps/candidates/add" type="button" className="btn btn-danger mr-4 mb-3  mb-sm-0"><i className="uil-plus mr-1"></i> Add Candidate</Link>
                    </div>
                </Col>
            </Row>
            {loading && <Loader />}

            <Row>
                {contacts.map((project, i) => {
                    return (
                        <Col lg={12} key={'proj-' + project._id}>
                            <Project project={project} />
                        </Col>
                    );
                })}
            </Row>

            <Row className="mb-3 mt-2">
                <Col>
                    {/* <div className="text-center">
                        <Button color="white">
                           Load more
                        </Button>
                    </div> */}
                </Col>
            </Row>
        </React.Fragment>
    );
};

export default Projects;
