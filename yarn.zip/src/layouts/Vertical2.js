// @flow
import React, { Component, Suspense,useContext, useEffect } from 'react';
import { Container } from 'reactstrap';
import { connect } from 'react-redux';

import { changeSidebarTheme, changeSidebarType } from '../redux/actions';
import * as layoutConstants from '../constants/layout';

import ThemeCustomizer from '../components/ThemeCustomizer';
import AuthContext from '../context/auth/authContext';
import Loader from '../components/Loader';
import{getMe} from '../helpers/authUtils';
// code splitting and lazy loading
// https://blog.logrocket.com/lazy-loading-components-in-react-16-6-6cea535c0b52
const LeftSidebar = React.lazy(() => import('../components/LeftSidebar'));
const Topbar = React.lazy(() => import('../components/Topbar'));
const Footer = React.lazy(() => import('../components/Footer'));
const RightSidebar = React.lazy(() => import('../components/RightSidebar'));


// loading
const emptyLoading = () => <div></div>;
const loading = () => <div className="text-center"></div>;

const openLeftMenu = () => {
    if (document.body) {
        if (document.body.classList.contains("sidebar-enable")) {
            document.body.classList.remove("sidebar-enable");
            this.props.changeSidebarType(layoutConstants.LEFT_SIDEBAR_TYPE_CONDENSED);
        } else {
            if (document.body.classList.contains("left-side-menu-condensed"))
                document.body.classList.remove("left-side-menu-condensed");
            document.body.classList.add("sidebar-enable");
        }
    }
};

const VerticalLayout = props => {
    const authContext = useContext(AuthContext);

    const { addEmployee, loading, error, addCandidate, contacts, getCandidates } = authContext;

    
// useEffect(() => {
//     //     // activate the condensed sidebar if smaller devices like ipad or tablet
//        if (window.innerWidth >= 768 && window.innerWidth <= 1028) {
//            props.changeSidebarType(layoutConstants.LEFT_SIDEBAR_TYPE_CONDENSED);
//        }
// }, []);
    console.log('from layut',loading)
        // get the child view which we would like to render
        const children = props.children || null;

        const isCondensed = props.layout.leftSideBarType === layoutConstants.LEFT_SIDEBAR_TYPE_CONDENSED;
        const isLight = props.layout.leftSideBarTheme === layoutConstants.LEFT_SIDEBAR_THEME_DEFAULT;
      
      
        const {name,role , company} = getMe() ;
console.log(name)
        return (
            <div className="app">
                {name == undefined && <Loader/>}
           { name != undefined &&    <div id="wrapper">

                    <Suspense >
                        <Topbar   />
                    </Suspense>
                    <Suspense >
                        <LeftSidebar
                            isCondensed={isCondensed}
                            isLight={isLight}
                            {...props}
                        />
                    </Suspense>

                    <div className="content-page">
                        <div className="content">
                            <Container fluid>
                                <Suspense >{children}</Suspense>
                            </Container>
                        </div>

                        <Suspense >
                            <Footer {...props} />
                        </Suspense>
                    </div>
                </div>

          }
            </div>
        );
    }

export default VerticalLayout
