import React, { useReducer } from 'react';
import axios from 'axios';
import AuthContext from './authContext';
import authReducer from './authReducer';
import setAuthToken from '../../utils/setAuthToken';
import { Cookies } from 'react-cookie';

import {
  REGISTER_SUCCESS,
  REGISTER_FAIL,
  USER_LOADED,
  AUTH_ERROR,
  LOGIN_SUCCESS,
  LOGIN_FAIL,
  LOGOUT,
  CLEAR_ERRORS,
  ADD_CONTACT,
  CONTACT_ERROR,
  GET_CONTACTS
} from '../types';

const AuthState = props => {
  const initialState = {
    token: localStorage.getItem('token'),
    isAuthenticated: null,
    loading: false,
    user: null,
    error: null,
    contacts: [],

  };

  const [state, dispatch] = useReducer(authReducer, initialState);

  //get candidate
  const getCandidates = async () => {
    const cookies = new Cookies();
    let token = cookies.get('token');
    setAuthToken(token);
    const config = {
      headers: {
        'Content-Type': 'application/json'
      }
    };
    setLoading()

    try {
      const res = await axios.get('/api/candidate/getCandidates', config);

      dispatch({
        type: GET_CONTACTS,
        payload: res.data.data
      });
    } catch (error) {
      console.log(error.response)
      console.log(error.message)

      //console.log(typeof(error))

      let message;
      if (error.response) {

        message = error.response.data.error;
      }
      else if (error.message) {
        message = error.message;
      }

      dispatch({
        type: LOGIN_FAIL,
        payload: message
      });
    }
  };
  //add candiadte
  const addCandidate = async (contact, history) => {
    const cookies = new Cookies();
    let token = cookies.get('token');
    setAuthToken(token);

    const config = {
      headers: {
        'Content-Type': 'application/json'
      }
    };
    setLoading()

    try {
      const res = await axios.post('/api/candidate/addCandidate', contact, config);
      console.log(res)
      dispatch({
        type: ADD_CONTACT,
        payload: res.data.data
      });
      history.push('/apps/candidates/list')
    } catch (error) {
      console.log(error.response)
      console.log(error.message)

      //console.log(typeof(error))

      let message;
      if (error.response) {

        message = error.response.data.error;
      }
      else if (error.message) {
        message = error.message;
      }

      dispatch({
        type: LOGIN_FAIL,
        payload: message
      });
    }
  };


  // Load User
  const loadUser = async () => {
    setLoading()
    const cookies = new Cookies();
    let token = cookies.get('token');
    setAuthToken(token);
    try {
      const res = await axios.get('/api/auth/me');
      console.log('result of me ', res)
      cookies.set('user',res.data.data)
      console.log('set token user details ',cookies.get('user'))

      dispatch({
        type: USER_LOADED,
        payload: res.data.data
      });
    } catch (err) {
      dispatch({ type: AUTH_ERROR });
    }
  };


  //Register company
  const companyRegister = async (formData, history) => {
    const config = {
      headers: {
        'Content-Type': 'application/json'
      }
    };
    setLoading()
    console.log(formData)
    try {
      const res = await axios.post('/api/company/addCompany', formData, config);

      history.push('/account/confirm');

      dispatch({
        type: REGISTER_SUCCESS,
        payload: res.data
      });


    } catch (error) {
      let message;
      if (error.response) {
        switch (error.response.status) {
          case 500:
            message = 'Internal Server Error';
            break;
          case 401:
            message = 'Invalid credentials';
            break;
          default:
            message = error.response.data.error;
        }
      }
      else if (error.message) {
        message = error.message;
      }


      dispatch({
        type: REGISTER_FAIL,
        payload: message
      });
    }
  };


  //SendInviteTo Employee
  const sendInviteToEmployee = async (formData, history) => {
    const cookies = new Cookies();
    let token = cookies.get('token');
    setAuthToken(token);

    const config = {
      headers: {
        'Content-Type': 'application/json'
      }
    };
    console.log(config)
    //setLoading();
    console.log(formData)
    setLoading()

    try {
      const response = await axios.post('/api/user/sendEmployeeInvite', formData, config);
      console.log(response)
      history.push('/apps/settings/list')
      const a =
      {
        name: formData.name,
        email: formData.email,
        role: formData.role.value

      }
      dispatch({
        type: ADD_CONTACT,
        payload: a
      });

      //  loadUser();
    } catch (error) {
      console.log(error.response)
      console.log(error.message)

      //console.log(typeof(error))

      let message;
      if (error.response) {

        message = error.response.data.error;
      }
      else if (error.message) {
        message = error.message;
      }

      dispatch({
        type: LOGIN_FAIL,
        payload: message
      });
    }
  };













  //get Users all of a company

  const getEmployees = async () => {
    const cookies = new Cookies();
    let token = cookies.get('token');
    setAuthToken(token);
    const config = {
      headers: {
        'Content-Type': 'application/json'
      }
    };
    setLoading()

    try {
      const res = await axios.get('/api/user/getUsers', config);
      console.log(res)
      dispatch({
        type: GET_CONTACTS,
        payload: res.data.data
      });
    } catch (error) {
      console.log(error.response)
      console.log(error.message)

      //console.log(typeof(error))

      let message;
      if (error.response) {

        message = error.response.data.error;
      }
      else if (error.message) {
        message = error.message;
      }

      dispatch({
        type: LOGIN_FAIL,
        payload: message
      });
    }
  };

  // Register User
  const register = async (formData, history) => {
    const config = {
      headers: {
        'Content-Type': 'application/json'
      }
    };
    setLoading()
    console.log(formData);
    try {
      const res = await axios.post('/api/auth/updatedetails', formData, config);
      dispatch({
        type: REGISTER_SUCCESS,
        payload: res.data
      });
      console.log(res);
      history.push('/account/login');

    } catch (error) {
      let message;
      if (error.response) {
            message = error.response.data.error;
      }
      else if (error.message) {
        message = error.message;
      }
      dispatch({
        type: REGISTER_FAIL,
        payload: message
      });
    }
  };

  // Login User
  const login = async (formData) => {
    const config = {
      headers: {
        'Content-Type': 'application/json'
      }
    };
    setLoading();

    try {

      const response = await axios.post('/api/auth/login', formData, config);
      const cookies = new Cookies();
      const problem = cookies.get('token');
      console.log('froom loginnnnnnnnnnnnnnnn',cookies.getAll());
      if(problem){

        throw Error;
      }
      cookies.set('token', response.data.token);
      cookies.set('user', response.data.data);
  
      // const reactToken = cookies.get('token');

      // console.log('reactToken', reactToken)
      dispatch({
        type: LOGIN_SUCCESS,
        payload: response.data
      });
      loadUser();

    } catch (error) {
      console.log(error.response)
      console.log(error.message)

      //console.log(typeof(error))

      let message;
      if (error.response) {
        switch (error.response.status) {
          case 500:
            message = 'Internal Server Error';
            break;
          case 401:
            message = 'Invalid credentials';
            break;
          default:
            message = error.response.data.error;
        }
      }
      else if (error.message) {
        message = error.message;
      }

      dispatch({
        type: LOGIN_FAIL,
        payload: message
      });
    }
  };

  // Logout
  const logout = (history) => {
    console.log('calloed logout')
    const cookies = new Cookies();
    cookies.remove('token');
    cookies.remove('user');

    console.log('from logut',cookies.getAll());

    dispatch({ type: LOGOUT });
    history.push('/account/login');

  }
  const setLoading = () => dispatch({ type: 'SET_LOADING' })

  // Clear Errors
  const clearErrors = () => dispatch({ type: CLEAR_ERRORS });

  return (
    <AuthContext.Provider
      value={{
        token: state.token,
        isAuthenticated: state.isAuthenticated,
        loading: state.loading,
        user: state.user,
        contacts: state.contacts,

        error: state.error,
        register,
        loadUser,
        login,
        logout,
        clearErrors,
        setLoading,
        companyRegister,
        sendInviteToEmployee,
        addCandidate,
        getCandidates,
        getEmployees
      }}
    >
      {props.children}
    </AuthContext.Provider>
  );
};

export default AuthState;
