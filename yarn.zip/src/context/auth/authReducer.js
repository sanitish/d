import {
  REGISTER_SUCCESS,
  REGISTER_FAIL,
  USER_LOADED,
  AUTH_ERROR,
  LOGIN_SUCCESS,
  LOGIN_FAIL,
  LOGOUT,
  CLEAR_ERRORS,
  SET_LOADING,
  ADD_CONTACT,
  GET_CONTACTS
} from '../types';

export default (state, action) => {
  switch (action.type) {

    case     USER_LOADED
    :
      return {
        ...state,
        user: action.payload,
        loading: false
      };
    case GET_CONTACTS:
      return {
        ...state,
        contacts: action.payload,
        loading: false
      };
    case ADD_CONTACT:
      return {
        ...state,
        contacts: [action.payload,...state.contacts ],
        loading: false
      };
    case USER_LOADED:
      return {
        ...state,
        isAuthenticated: true,
        loading: false,
        user: action.payload
      };
    case REGISTER_SUCCESS:
      return { ...state, loading: false ,error: null};
    case LOGIN_SUCCESS:
      return {
        ...state,
        ...action.payload,
        error: null,
        isAuthenticated: true,
        loading: false,
        user:action.payload.data
      };
    case REGISTER_FAIL:
      return { ...state, error: action.payload, loading: false };
    case AUTH_ERROR:
      return { ...state, error: action.payload, loading: false };
    case LOGIN_FAIL:
   
        return { ...state, error: action.payload, loading: false };


    case LOGOUT:
      localStorage.removeItem('token');
      return {
        ...state,
        token: null,
        isAuthenticated: false,
        loading: false,
        user: null,

        error: null
      };
    case CLEAR_ERRORS:
      return {
        ...state,
        error: null
      };

      case SET_LOADING:
        return{
          ...state,
          loading:true
        }
    default:
      return state;
  }
};
